<?php
session_start();
// بررسی اینکه آیا کاربر مدیر است یا خیر
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit();
}

include 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $category = $_POST['category'];

    // آپلود تصویر
    $image = '';
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $target_dir = "uploads/";
        $target_file = $target_dir . basename($_FILES['image']['name']);
        if (move_uploaded_file($_FILES['image']['tmp_name'], $target_file)) {
            $image = $target_file;
        }
    }

    // درج محصول در پایگاه داده
    $stmt = $conn->prepare("INSERT INTO products (name, description, price, image, category) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$name, $description, $price, $image, $category]);

    echo "<p>محصول با موفقیت اضافه شد!</p>";
}
?>

<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>افزودن محصول</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <h1>افزودن محصول جدید</h1>
        <form action="add_product.php" method="post" enctype="multipart/form-data">
            <label for="name">نام محصول:</label>
            <input type="text" id="name" name="name" required>

            <label for="description">توضیحات محصول:</label>
            <textarea id="description" name="description" required></textarea>

            <label for="price">قیمت محصول (تومان):</label>
            <input type="number" id="price" name="price" step="0.01" required>

            <label for="category">دسته‌بندی:</label>
            <select id="category" name="category" required>
                <option value="electronics">الکترونیک</option>
                <option value="clothing">پوشاک</option>
                <option value="home">خانه و آشپزخانه</option>
                <option value="sports">ورزشی</option>
            </select>

            <label for="image">تصویر محصول:</label>
            <input type="file" id="image" name="image" accept="image/*" required>

            <button type="submit">افزودن محصول</button>
        </form>
    </div>
</body>
</html>