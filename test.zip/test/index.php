<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include 'db.php';
include 'includes/header.php';
?>

<main >
    <button  id="theme-toggle">🌓 تغییر تم</button> <!-- دکمه تغییر تم -->

    <div class="hero-banner">
        <img src="images/banner.jpg" alt="تخفیف‌های ویژه" class="hero-image">
    </div>

<link rel="stylesheet" href="style.css">

    <div class="container";>
        <h2 class="section-title">محصولات ویژه</h2>
        <div class="products-grid">
            <?php
            $stmt = $conn->query("SELECT * FROM products LIMIT 8"); // نمایش 8 محصول
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                echo "<div class='product-card'>
                        <a href='product.php?id={$row['id']}'>
                            <img src='{$row['image']}' alt='{$row['name']}' class='product-image'>
                        </a>
                        
                        <div class='product-info'>
                            <h3 class='product-name'>{$row['name']}</h3>
                            <p class='product-price'>{$row['price']} تومان</p>
                            <button class='add-to-cart' data-id='{$row['id']}'>افزودن به سبد خرید</button>
                       
                            </div>
                      </div>";
            }
            ?>
        </div>
    </div>
</main>


<script>
document.querySelect<script>
document.querySelectorAll('.add-to-cart').forEach(button => {
    button.addEventListener('click', function() {
        let productId = this.getAttribute('data-id');

        fetch('cart_handler.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `action=add&product_id=${productId}&quantity=1`
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                document.getElementById('cart-count').textContent = data.cart_count;
                alert('محصول به سبد خرید اضافه شد!');
            } else {
                alert(data.message);
            }
        });
    });
}); 'includes/footer.php'; ?>
