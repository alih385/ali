document.addEventListener("DOMContentLoaded", function() {
    // تغییر تصویر اصلی گالری
    const thumbnails = document.querySelectorAll(".thumbnail");
    const mainImage = document.getElementById("main-img");

    thumbnails.forEach(thumb => {
        thumb.addEventListener("click", function() {
            mainImage.src = this.src;
        });
    });

    // افزودن محصول به سبد خرید با AJAX
    const addToCartForm = document.getElementById("add-to-cart-form");
    if (addToCartForm) {
        addToCartForm.addEventListener("submit", function(e) {
            e.preventDefault();

            const formData = new FormData(this);
            formData.append("action", "add");

            fetch("cart_handler.php", {
                method: "POST",
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                let messageElement = document.getElementById("message");
                if (data.status === "success") {
                    messageElement.textContent = data.message;
                    messageElement.style.color = "green";
                    document.getElementById("cart-count").textContent = data.cart_count;
                } else {
                    messageElement.textContent = data.message;
                    messageElement.style.color = "red";
                }
            })
            .catch(error => {
                console.error("Error:", error);
                document.getElementById("message").textContent = "خطا در ارتباط با سرور!";
                document.getElementById("message").style.color = "red";
            });
        });
    }

    // ارسال نظر کاربران با AJAX
    const commentForm = document.getElementById("comment-form");
    if (commentForm) {
        commentForm.addEventListener("submit", function(e) {
            e.preventDefault();

            const formData = new FormData(this);

            fetch("comment_handler.php", {
                method: "POST",
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                let messageElement = document.getElementById("comment-message");
                if (data.status === "success") {
                    messageElement.textContent = data.message;
                    messageElement.style.color = "green";
                    setTimeout(() => location.reload(), 1000);
                } else {
                    messageElement.textContent = data.message;
                    messageElement.style.color = "red";
                }
            })
            .catch(error => {
                console.error("Error:", error);
                document.getElementById("comment-message").textContent = "خطا در ارسال نظر!";
                document.getElementById("comment-message").style.color = "red";
            });
        });
    }
});
