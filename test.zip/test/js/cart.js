document.addEventListener("DOMContentLoaded", function() {
    // افزودن محصول به سبد خرید
    const addToCartForm = document.getElementById("add-to-cart-form");
    if (addToCartForm) {
        addToCartForm.addEventListener("submit", function(e) {
            e.preventDefault();

            const formData = new FormData(this);
            formData.append("action", "add");

            fetch("cart_handler.php", {
                method: "POST",
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                let messageElement = document.getElementById("message");
                if (data.status === "success") {
                    messageElement.textContent = data.message;
                    messageElement.style.color = "green";
                    document.getElementById("cart-count").textContent = data.cart_count;
                } else {
                    messageElement.textContent = data.message;
                    messageElement.style.color = "red";
                }
            })
            .catch(error => {
                console.error("Error:", error);
                document.getElementById("message").textContent = "خطا در ارتباط با سرور!";
                document.getElementById("message").style.color = "red";
            });
        });
    }

    // تغییر تصویر گالری
    const thumbnails = document.querySelectorAll(".thumbnail");
    const mainImage = document.getElementById("main-img");

    thumbnails.forEach(thumb => {
        thumb.addEventListener("click", function() {
            mainImage.src = this.src;
        });
    });

    // افزایش و کاهش تعداد محصول در سبد خرید
    document.querySelectorAll('.increase').forEach(button => {
        button.addEventListener('click', function() {
            updateCart('increase', this.getAttribute('data-id'));
        });
    });

    document.querySelectorAll('.decrease').forEach(button => {
        button.addEventListener('click', function() {
            updateCart('decrease', this.getAttribute('data-id'));
        });
    });

    // حذف محصول از سبد خرید
    document.querySelectorAll('.remove-btn').forEach(button => {
        button.addEventListener('click', function() {
            updateCart('remove', this.getAttribute('data-id'));
        });
    });
});

function updateCart(action, productId) {
    let data = `action=${action}&product_id=${productId}`;

    fetch('cart_handler.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: data
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            let cartCount = document.getElementById('cart-count');
            if (cartCount) {
                cartCount.textContent = data.cart_count;
            }
            location.reload();
        } else {
            alert('خطایی رخ داده است. لطفا دوباره تلاش کنید.');
        }
    })
    .catch(error => {
        console.error("خطا در ارتباط با سرور:", error);
    });
}
