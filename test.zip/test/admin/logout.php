<?php
session_start();
session_unset(); // حذف تمام داده‌های سشن
session_destroy(); // نابود کردن سشن

header("Location: login.php"); // هدایت به صفحه ورود پس از خروج
exit;
?>
