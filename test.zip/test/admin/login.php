<?php
session_start(); // شروع سشن برای ذخیره داده‌ها

// بررسی ورود قبلی
if (isset($_SESSION['admin_logged_in'])) {
    header("Location: index.php"); // اگر وارد شده‌اید به پنل مدیریت هدایت می‌شود
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // دریافت اطلاعات وارد شده توسط کاربر
    $username = $_POST['username'];
    $password = $_POST['password'];

    // اتصال به پایگاه داده
    $servername = "localhost";  // نام سرور پایگاه داده
    $dbname = "shop";    // نام پایگاه داده
    $dbusername = "root";       // نام کاربری پایگاه داده
    $dbpassword = "";          // رمز عبور پایگاه داده

    // ایجاد اتصال به پایگاه داده
    $conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);

    // بررسی اتصال
    if ($conn->connect_error) {
        die("اتصال به پایگاه داده برقرار نشد: " . $conn->connect_error);
    }

    // جلوگیری از حملات SQL Injection
    $username = $conn->real_escape_string($username);
    $password = $conn->real_escape_string($password);

    // پرس و جو برای پیدا کردن کاربر با نام کاربری وارد شده
    $sql = "SELECT * FROM users WHERE username = '$username' LIMIT 1";
    $result = $conn->query($sql);

    // بررسی وجود کاربر
    if ($result->num_rows > 0) {
        // دریافت اطلاعات کاربر
        $row = $result->fetch_assoc();

        // بررسی رمز عبور (در پروژه واقعی باید رمز عبور هش شده را مقایسه کنید)
        if ($password === $row['password']) {
            $_SESSION['admin_logged_in'] = true;  // ذخیره وضعیت ورود
            header("Location: index.php"); // هدایت به داشبورد پنل مدیریت
            exit;
        } else {
            $error_message = 'رمز عبور اشتباه است.';
        }
    } else {
        $error_message = 'نام کاربری اشتباه است.';
    }

    // بستن اتصال
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ورود به پنل مدیریت</title>
    <link href="https://fonts.googleapis.com/css2?family=Vazirmatn&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="login-container">
        <h2>ورود به پنل مدیریت</h2>

        <!-- نمایش پیام خطا در صورت اشتباه بودن نام کاربری یا رمز عبور -->
        <?php if (isset($error_message)) { echo "<p style='color:red;'>$error_message</p>"; } ?>

        <form method="POST" action="login.php">
            <div class="form-group">
                <label for="username">نام کاربری</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div class="form-group">
                <label for="password">رمز عبور</label>
                <input type="password" id="password" name="password" required>
            </div>
            <button type="submit">ورود</button>
        </form>
    </div>
</body>
</html>
