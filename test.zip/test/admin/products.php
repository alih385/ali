<?php
session_start();

// بررسی لاگین بودن مدیر
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.php");
    exit;
}

include 'db.php';
include 'admin-header.php';

// دریافت لیست محصولات
$stmt = $conn->prepare("SELECT * FROM products");
$stmt->execute();
$products = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!-- محتوای صفحه مدیریت محصولات -->
<div class="content">
    <h2>مدیریت محصولات</h2>

    <!-- دکمه افزودن محصول -->
    <a href="add_product.php" class="btn add-btn">➕ افزودن محصول جدید</a>

    <!-- جدول محصولات -->
    <table class="product-table">
        <thead>
            <tr>
                <th>تصویر</th>
                <th>نام محصول</th>
                <th>قیمت</th>
                <th>توضیحات</th>
                <th>عملیات</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($products as $product): ?>

            <tr>
                <td><img src="uploads/<?= htmlspecialchars($product['image']) ?>" alt="<?= htmlspecialchars($product['name']) ?>" class="product-img"></td>
                <td><?= htmlspecialchars($product['name']) ?></td>
                <td><?= number_format($product['price']) ?> تومان</td>
                <td><?= mb_substr(htmlspecialchars($product['description']), 0, 50) ?>...</td>
                <td>
                    <a href="edit_product.php?id=<?= $product['id'] ?>" class="btn edit-btn">✏️ ویرایش</a>
                    <a href="delete_product.php?id=<?= $product['id'] ?>" onclick="return confirm('آیا مطمئن هستید؟')" class="btn delete-btn">❌ حذف</a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
 <link rel="stylesheet" href="products.css">

</div> <!-- بسته شدن main-content از admin-header.php -->
</body>
</html>
