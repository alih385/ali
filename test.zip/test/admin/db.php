<?php
$host = 'localhost'; // آدرس سرور دیتابیس
$dbname = 'shop';    // نام دیتابیس
$username = 'root';  // نام کاربری دیتابیس
$password = '';      // رمز عبور دیتابیس

try {
    // ایجاد اتصال به دیتابیس با استفاده از PDO
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    
    // تنظیم حالت خطا به حالت استثنا (Exception)
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // تنظیم کدگذاری کاراکترها به UTF-8
    $conn->exec("SET NAMES utf8");
} catch(PDOException $e) {
    // نمایش خطا در صورت عدم اتصال
    die("Connection failed: " . $e->getMessage());
}
?>