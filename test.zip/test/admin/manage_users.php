<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.php");
    exit;
}

include 'db.php';
include 'admin-header.php';

// دریافت لیست کاربران از دیتابیس
$stmt = $conn->prepare("SELECT * FROM users");
$stmt->execute();
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="content">
    <h2>مدیریت کاربران</h2>

    <a href="add_user.php" class="btn add-btn">➕ افزودن کاربر جدید</a>

    <table>
        <thead>
            <tr>
                <th>نام کاربری</th>
                <th>نقش</th>
                <th>میزان دسترسی</th>
                <th>عملیات</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($users as $user): ?>
                <tr>
                    <td><?= htmlspecialchars($user['username']) ?></td>
                    <td><?= htmlspecialchars($user['role']) ?></td>
                    <td><?= htmlspecialchars($user['access_level']) ?></td>
                    <td>
                        <a href="edit_user.php?id=<?= $user['id'] ?>" class="btn edit-btn">ویرایش</a>
                        <a href="delete_user.php?id=<?= $user['id'] ?>" onclick="return confirm('آیا مطمئن هستید؟')" class="btn delete-btn">حذف</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
        <link rel="stylesheet" href="manage_users.css">

    </table>
</div>
