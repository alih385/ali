<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.php");
    exit;
}

include 'db.php';

// پردازش فرم افزودن کاربر جدید
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT); // رمزنگاری رمز عبور
    $role = $_POST['role'];
    $access_level = $_POST['access_level'];

    // بررسی تکراری نبودن نام کاربری
    $stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $user_exists = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user_exists) {
        // اگر نام کاربری تکراری باشد، پیام خطا نمایش داده شود
        $error_message = "نام کاربری از قبل وجود دارد. لطفاً نام کاربری دیگری انتخاب کنید.";
    } else {
        // اگر نام کاربری تکراری نبود، کاربر جدید اضافه شود
        $stmt = $conn->prepare("INSERT INTO users (username, password, role, access_level) VALUES (?, ?, ?, ?)");
        if ($stmt->execute([$username, $password, $role, $access_level])) {
            header("Location: manage_users.php?success=1");
            exit;
        } else {
            $error_message = "خطا در افزودن کاربر!";
        }
    }
}
?>

<!-- فرم افزودن کاربر جدید -->
<div class="content">
    <h2>افزودن کاربر جدید</h2>
    <link rel="stylesheet" href="add_user.css">

    <!-- نمایش پیام خطا -->
    <?php if (isset($error_message)): ?>
        <div class="error-message">
            <?php echo $error_message; ?>
        </div>
    <?php endif; ?>

    <form action="add_user.php" method="POST">
        <label>نام کاربری:</label>
        <input type="text" name="username" required>

        <label>رمز عبور:</label>
        <input type="password" name="password" required>

        <label>نقش کاربر:</label>
        <select name="role">
            <option value="admin">مدیر</option>
            <option value="editor">ویراستار</option>
            <option value="viewer">مشاهده‌کننده</option>
        </select>

        <label>میزان دسترسی:</label>
        <input type="number" name="access_level" min="1" max="10" value="1">

        <button type="submit" class="btn submit-btn">➕ افزودن کاربر</button>
    </form>
</div>