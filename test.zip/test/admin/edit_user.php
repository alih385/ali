<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.php");
    exit;
}

include 'db.php';

// دریافت اطلاعات کاربر برای ویرایش
if (isset($_GET['id'])) {
    $stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$_GET['id']]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $role = $_POST['role'];
    $access_level = $_POST['access_level'];

    // ویرایش اطلاعات کاربر در دیتابیس
    $stmt = $conn->prepare("UPDATE users SET username = ?, role = ?, access_level = ? WHERE id = ?");
    $stmt->execute([$username, $role, $access_level, $_GET['id']]);

    header("Location: manage_users.php?success=1");
    exit;
}
?>

<!-- فرم ویرایش کاربر -->
<div class="content">
    <h2>ویرایش کاربر</h2>
    <link rel="stylesheet" href="edit_user.css">

    <form action="edit_user.php?id=<?= $user['id'] ?>" method="POST">
        <label>نام کاربری:</label>
        <input type="text" name="username" value="<?= htmlspecialchars($user['username']) ?>" required>

        <label>نقش کاربر:</label>
        <select name="role">
            <option value="admin" <?= ($user['role'] == 'admin') ? 'selected' : '' ?>>مدیر</option>
            <option value="editor" <?= ($user['role'] == 'editor') ? 'selected' : '' ?>>ویراستار</option>
            <option value="viewer" <?= ($user['role'] == 'viewer') ? 'selected' : '' ?>>مشاهده‌کننده</option>
        </select>

        <label>میزان دسترسی:</label>
        <input type="number" name="access_level" min="1" max="10" value="<?= htmlspecialchars($user['access_level']) ?>">

        <button type="submit" class="btn submit-btn">ویرایش کاربر</button>
    </form>
</div>
