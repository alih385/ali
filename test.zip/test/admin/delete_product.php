<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.php");
    exit;
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "shop";

// اتصال به دیتابیس
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("اتصال ناموفق: " . $conn->connect_error);
}

// بررسی شناسه محصول
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $sql = "DELETE FROM products WHERE id = $id";

    if ($conn->query($sql) === TRUE) {
        echo "محصول با موفقیت حذف شد!";
    } else {
        echo "خطا در حذف محصول: " . $conn->error;
    }
}

// هدایت به مدیریت محصولات
header("Location: manage_products.php");
exit;
?>
