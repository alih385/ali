<?php
// چک کردن و شروع کردن session در صورتی که فعال نباشد
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// بررسی لاگین بودن مدیر
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>پنل مدیریت</title>
    <link href="https://fonts.googleapis.com/css2?family=Vazirmatn&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="sidebar">
        <h2>مدیریت سایت</h2>
        <ul>
            <li><a href="dashboard.php">🏠 پیشخوان</a></li>
            <li><a href="products.php" class="active">📦 مدیریت محصولات</a></li>
            <li><a href="manage_users.php">👥 مدیریت کاربران</a></li>
            <li><a href="orders.php">🛒 مدیریت سفارشات</a></li>
            <li><a href="reports.php">📊 آمار سایت</a></li>
            <li><a href="support.php">📞 پشتیبانی</a></li>
            <li><a href="logout.php" class="logout">🚪 خروج</a></li>
        </ul>
    </div>

    <div class="main-content">
        <header>
            <div class="header-left">
                <a href=".../index.php">نمایش سایت</a>
            </div>
            <div class="header-right">
                <div class="user-info">
                    <span>سلام، <?= isset($_SESSION['username']) ? $_SESSION['username'] : 'مدیر' ?></span>
                    <a href="logout.php">خروج</a>
                </div>
            </div>
        </header>
