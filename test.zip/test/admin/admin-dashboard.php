<div class="admin-dashboard">
    <h2>داشبورد پنل مدیریت</h2>
    <div class="stat-boxes">
        <div class="stat-box">
            <h3>تعداد محصولات</h3>
            <p>120 محصول</p>
        </div>
        <div class="stat-box">
            <h3>تعداد کاربران</h3>
            <p>80 کاربر</p>
        </div>
        <div class="stat-box">
            <h3>تعداد سفارشات</h3>
            <p>300 سفارش</p>
        </div>
    </div>
</div>
