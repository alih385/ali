<?php
include 'admin-header.php';
?>

<!-- بخش اصلی -->
<div class="content">
    <h1>خوش آمدید به پنل مدیریت</h1>
</div>

</div> <!-- بستن `main-content` -->
</body>
</html>
