<?php
session_start();

// بررسی لاگین بودن مدیر
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.php");
    exit;
}

include 'db.php';
include 'admin-header.php';

// پردازش فرم افزودن محصول
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $price = $_POST['price'];
    $description = $_POST['description'];

    // پردازش آپلود تصویر
    $image_name = $_FILES['image']['name'];
    $image_tmp = $_FILES['image']['tmp_name'];
    $upload_dir = "uploads/";

    // بررسی وجود پوشه 'uploads' و ساخت آن در صورت نیاز
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0777, true); // ایجاد پوشه uploads در صورت نبود
    }

    // انتقال تصویر به پوشه
    if (move_uploaded_file($image_tmp, $upload_dir . $image_name)) {
        // افزودن محصول به دیتابیس با استفاده از PDO
        $stmt = $conn->prepare("INSERT INTO products (name, price, description, image) VALUES (:name, :price, :description, :image)");
        
        // بایند کردن مقادیر به متغیرهای SQL
        $stmt->bindParam(':name', $name, PDO::PARAM_STR);
        $stmt->bindParam(':price', $price, PDO::PARAM_INT);
        $stmt->bindParam(':description', $description, PDO::PARAM_STR);
        $stmt->bindParam(':image', $image_name, PDO::PARAM_STR);

        if ($stmt->execute()) {
            header("Location: products.php?success=1");
            exit;
        } else {
            $error = "خطا در افزودن محصول!";
        }
    } else {
        $error = "خطا در آپلود تصویر!";
    }
}
?>

<!-- محتوای صفحه افزودن محصول -->
<div class="content">
    <h2>افزودن محصول جدید</h2>

    <?php if (isset($error)) echo "<p class='error'>$error</p>"; ?>

    <form action="add_product.php" method="POST" enctype="multipart/form-data">
        <label>نام محصول:</label>
        <input type="text" name="name" required>

        <label>قیمت:</label>
        <input type="number" name="price" required>

        <label>توضیحات:</label>
        <textarea name="description"></textarea>

        <label>تصویر:</label>
        <input type="file" name="image" required>

        <button type="submit" class="btn submit-btn">➕ افزودن</button>
    </form>
</div>

<link rel="stylesheet" href="add_product.css">

</div> <!-- بسته شدن main-content از admin-header.php -->
</body>
</html>
