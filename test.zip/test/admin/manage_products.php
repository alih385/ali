<?php
session_start();

// بررسی اینکه کاربر لاگین کرده باشد
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.php");
    exit;
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "shop";

// اتصال به پایگاه داده
$conn = new mysqli($servername, $username, $password, $dbname);

// بررسی خطای اتصال
if ($conn->connect_error) {
    die("اتصال ناموفق: " . $conn->connect_error);
}

// دریافت لیست محصولات از دیتابیس
$sql = "SELECT * FROM products";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>مدیریت محصولات</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h2>مدیریت محصولات</h2>

    <!-- دکمه افزودن محصول -->
    <a href="add_product.php">افزودن محصول جدید</a>

    <table border="1">
        <tr>
            <th>شناسه</th>
            <th>نام محصول</th>
            <th>قیمت</th>
            <th>توضیحات</th>
            <th>تصویر</th>
            <th>عملیات</th>
        </tr>
        
        <?php while ($row = $result->fetch_assoc()): ?>
        <tr>
            <td><?= $row['id'] ?></td>
            <td><?= $row['name'] ?></td>
            <td><?= $row['price'] ?> تومان</td>
            <td><?= $row['description'] ?></td>
            <td><img src="uploads/<?= $row['image'] ?>" width="50"></td>
            <td>
                <a href="delete_product.php?id=<?= $row['id'] ?>" onclick="return confirm('آیا مطمئن هستید؟')">❌ حذف</a>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>

</body>
</html>

<?php
$conn->close();
?>
