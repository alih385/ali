<?php
session_start();

// دریافت مقادیر از درخواست POST
$action = $_POST['action'] ?? '';
$product_id = $_POST['product_id'] ?? 0;
$name = $_POST['name'] ?? '';
$price = isset($_POST['price']) ? (int) $_POST['price'] : 0;
$image = $_POST['image'] ?? '';

// مدیریت عملیات‌های مختلف سبد خرید
if ($action === 'add') {
    // اگر محصول قبلاً در سبد خرید نیست
    if (!isset($_SESSION['cart'][$product_id])) {
        $_SESSION['cart'][$product_id] = [
            'id' => $product_id,
            'name' => $name,
            'price' => $price,
            'image' => $image,
            'quantity' => 1
        ];
    } else {
        // اگر محصول در سبد خرید وجود دارد، تعداد آن افزایش یابد
        $_SESSION['cart'][$product_id]['quantity'] += 1;
    }
} elseif ($action === 'increase') {
    // افزایش تعداد محصول
    if (isset($_SESSION['cart'][$product_id])) {
        $_SESSION['cart'][$product_id]['quantity'] += 1;
    }
} elseif ($action === 'decrease') {
    // کاهش تعداد محصول
    if (isset($_SESSION['cart'][$product_id])) {
        if ($_SESSION['cart'][$product_id]['quantity'] > 1) {
            $_SESSION['cart'][$product_id]['quantity'] -= 1;
        } else {
            unset($_SESSION['cart'][$product_id]);
        }
    }
} elseif ($action === 'remove') {
    // حذف محصول از سبد خرید
    if (isset($_SESSION['cart'][$product_id])) {
        unset($_SESSION['cart'][$product_id]);
    }
}

// محاسبه تعداد محصولات در سبد خرید
$cart_count = array_sum(array_column($_SESSION['cart'], 'quantity'));

// ارسال پاسخ JSON
echo json_encode([
    'status' => 'success',
    'cart_count' => $cart_count,
    'message' => 'سبد خرید به‌روزرسانی شد.'
]);
?>
