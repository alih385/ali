<?php
session_start();
include 'db.php';

// بررسی روش درخواست POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // دریافت و تمیز کردن ورودی‌ها
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $address = trim($_POST['address']);
    $postal_code = trim($_POST['postal_code']);

    // بررسی پر بودن تمامی فیلدها
    if (empty($username) || empty($password) || empty($email) || empty($phone) || empty($address) || empty($postal_code)) {
        $error = "لطفاً تمامی فیلدها را پر کنید!";
    } elseif (strlen($password) < 6) {
        $error = "رمز عبور باید حداقل ۶ کاراکتر باشد!";
    } else {
        // بررسی اینکه نام کاربری یا ایمیل از قبل وجود دارد یا نه
        $stmt = $conn->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
        $stmt->execute([$username, $email]);
        
        if ($stmt->fetch()) {
            $error = "نام کاربری یا ایمیل قبلاً ثبت شده است!";
        } else {
            // هش کردن رمز عبور
            $hashed_password = password_hash($password, PASSWORD_BCRYPT);

            // درج اطلاعات در پایگاه داده
            $stmt = $conn->prepare("INSERT INTO users (username, password, email, phone, address, postal_code) VALUES (?, ?, ?, ?, ?, ?)");
            
            if ($stmt->execute([$username, $hashed_password, $email, $phone, $address, $postal_code])) {
                $success = "ثبت نام با موفقیت انجام شد! <a href='login.php'>ورود به حساب</a>";
            } else {
                $error = "خطایی در ثبت‌نام رخ داد. لطفاً دوباره تلاش کنید.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="FA-IR" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>فرم ثبت نام - میهن جاوااسکریپت</title>
    <link rel="stylesheet" href="./assets/css/vendor/materialdesignicons.min.css">
    <link rel="stylesheet" href="./assets/css/vendor/bootstrap.min.css">
    <link rel="stylesheet" href="./assets/css/main.css">
</head>
<body>
    <main class="main-content mt-4 mb-4">
        <div class="container main-container">
            <div class="row">
                <div class="mx-auto col-xl-4 col-lg-5 col-md-7 col-12">
                    <div class="text-center mb-3">
                        <a href="#">
                            <img src="" alt="logo" class="img-fluid">
                        </a>
                    </div>
                    <div class="auth-wrapper form-ui border pt-4">
                        <div class="section-title title-wide mb-1">
                            <h2 class="font-weight-bold"> ثبت نام </h2>
                        </div>
                        <div class="message-light"> اگر قبلا با ایمیل ثبت‌نام کرده‌اید، نیاز به ثبت‌نام مجدد با شماره همراه ندارید </div>
                        
                        <?php if (isset($error)): ?>
                            <div class="alert alert-danger"><?php echo $error; ?></div>
                        <?php endif; ?>
                        <?php if (isset($success)): ?>
                            <div class="alert alert-success"><?php echo $success; ?></div>
                        <?php endif; ?>

                        <form action="register.php" method="post">
                            <div class="form-row-title">
                                <h3> نام کاربری </h3>
                            </div>
                            <div class="form-row with-icon">
                                <input type="text" name="username" class="input-ui pr-2" placeholder="نام کاربری خود را وارد نمایید" required>
                                <i class="mdi mdi-account-circle-outline"></i>
                            </div>
                            <div class="form-row-title">
                                <h3> ایمیل </h3>
                            </div>
                            <div class="form-row with-icon">
                                <input type="email" name="email" class="input-ui pr-2" placeholder="ایمیل خود را وارد نمایید" required>
                                <i class="mdi mdi-email-outline"></i>
                            </div>
                            <div class="form-row-title">
                                <h3> رمز عبور </h3>
                            </div>
                            <div class="form-row with-icon">
                                <input type="password" name="password" class="input-ui pr-2" placeholder="رمز عبور خود را وارد نمایید" required>
                                <i class="mdi mdi-lock-open-variant-outline"></i>
                            </div>
                            <div class="form-row-title">
                                <h3> شماره تلفن </h3>
                            </div>
                            <div class="form-row with-icon">
                                <input type="text" name="phone" class="input-ui pr-2" placeholder="شماره تلفن خود را وارد نمایید" required>
                                <i class="mdi mdi-phone"></i>
                            </div>
                            <div class="form-row-title">
                                <h3> آدرس </h3>
                            </div>
                            <div class="form-row with-icon">
                                <textarea name="address" class="input-ui pr-2" placeholder="آدرس خود را وارد نمایید" required></textarea>
                                <i class="mdi mdi-map-marker"></i>
                            </div>
                            <div class="form-row-title">
                                <h3> کد پستی </h3>
                            </div>
                            <div class="form-row with-icon">
                                <input type="text" name="postal_code" class="input-ui pr-2" placeholder="کد پستی خود را وارد نمایید" required>
                                <i class="mdi mdi-post"></i>
                            </div>
                            <div class="form-row mt-2">
                                <div class="custom-control custom-checkbox float-right mt-2">
                                    <input type="checkbox" class="custom-control-input" id="check1" required>
                                    <label for="check1" class="custom-control-label text-justify">
                                        <a href="#">حریم خصوصی</a> و <a href="#">شرایط و قوانین</a> استفاده از سرویس های سایت را مطالعه نموده و با کلیه موارد آن موافقم. </label>
                                </div>
                            </div>
                            <div class="form-row mt-3">
                                <button type="submit" class="btn-primary-cm btn-with-icon mx-auto w-100">
                                    <i class="mdi mdi-account-circle-outline"></i> ثبت نام </button>
                            </div>
                        </form>
                        <div class="form-footer mt-3">
                            <div>
                                <span class="font-weight-bold">قبلا ثبت نام کرده اید؟</span>
                                <a href="login.php" class="mr-1 mt-2">وارد شوید</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
</body>
</html>