<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    die("❌ لطفا ابتدا وارد حساب کاربری خود شوید.");
}

$cart = $_SESSION['cart'] ?? [];
if (empty($cart)) {
    die("❌ سبد خرید شما خالی است.");
}

// محاسبه مجموع قیمت سبد خرید
$total_price = 0;
foreach ($cart as $item) {
    $total_price += $item['price'] * $item['quantity'];
}

// درج سفارش در دیتابیس
$stmt = $conn->prepare("INSERT INTO orders (user_id, total_price, status) VALUES (?, ?, 'pending')");
$stmt->execute([$_SESSION['user_id'], $total_price]);
$order_id = $conn->lastInsertId();

// مقدار کلید API زیبال (دریافت از پنل کاربری)
$merchant = "67b25a596f38030016730639"; // ❗ کلید API خود را جایگزین کنید
$callback_url = "http://localhost/verify.php"; // ❗ آدرس تأیید پرداخت را درست تنظیم کنید

// درخواست به درگاه زیبال
$data = [
    "merchant" => $merchant,
    "amount" => $total_price * 10, // **زیبال مبلغ را به "ریال" دریافت می‌کند، پس در 10 ضرب کنید!**
    "callbackUrl" => $callback_url,
    "orderId" => $order_id
];

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://api.zibal.ir/request");
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, ["Content-Type: application/json"]);

$response = curl_exec($ch);
$http_status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

// بررسی خطای CURL
if ($response === false || $http_status !== 200) {
    die("❌ خطا در برقراری ارتباط با سرور زیبال. لطفاً مجدداً تلاش کنید.");
}

$result = json_decode($response, true);

// بررسی پاسخ درگاه زیبال
if (isset($result["result"]) && $result["result"] == 100) {
    $trackId = $result["trackId"];
    header("Location: https://gateway.zibal.ir/start/$trackId");
    exit();
} else {
    die("❌ خطا در اتصال به درگاه پرداخت: " . ($result["message"] ?? "کد خطا: " . $result["result"]));
}
?>
