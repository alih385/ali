<?php
session_start();

// دریافت مقادیر از درخواست GET
$amount = $_GET['amount'] ?? 0;
$status = $_GET['status'] ?? '';
$zibal_payment_id = $_GET['payment_id'] ?? '';

// بررسی اینکه پارامترهای لازم وجود دارند
if ($amount && $status && $zibal_payment_id) {

    // نمایش پارامترها برای بررسی
    echo '<pre>';
    print_r($_GET); // این خط برای بررسی پارامترهای دریافتی است
    echo '</pre>';

    // اگر پرداخت موفقیت‌آمیز بوده است
    if ($status == "OK") {
        // درخواست به سرور زیبال جهت تایید پرداخت
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "https://gateway.zibal.ir/v1/verify");
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, [
            'merchant' => 'YOUR_MERCHANT_ID', // شناسه مرچنت خود را وارد کنید
            'payment_id' => $zibal_payment_id,
            'amount' => $amount
        ]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($ch);
        curl_close($ch);

        // بررسی نتیجه تایید پرداخت
        $response_data = json_decode($response, true);
        if ($response_data['status'] == 100) {
            // پرداخت موفقیت‌آمیز بوده است
            echo "پرداخت شما با موفقیت انجام شد.";
        } else {
            // در صورتی که پرداخت موفقیت‌آمیز نباشد
            echo "پرداخت ناموفق بود. کد خطا: " . $response_data['status'];
        }
    } else {
        // اگر پرداخت ناموفق بود
        echo "پرداخت ناموفق بود.";
    }
} else {
    echo "پارامترهای مورد نیاز ارسال نشده‌اند.";
}
?>
