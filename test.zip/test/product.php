<?php
session_start();
include 'db.php';
include 'includes/header.php';

if (!isset($_GET['id'])) {
    die("شناسه محصول مشخص نشده است.");
}

$id = $_GET['id'];

// دریافت اطلاعات محصول از دیتابیس
$stmt = $conn->prepare("SELECT * FROM products WHERE id = ?");
$stmt->execute([$id]);
$product = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$product) {
    die("محصول یافت نشد.");
}

// دریافت تصاویر مرتبط با محصول
$stmt = $conn->prepare("SELECT image FROM product_images WHERE product_id = ?");
$stmt->execute([$id]);
$images = $stmt->fetchAll(PDO::FETCH_ASSOC);

// دریافت نظرات محصول
$stmt = $conn->prepare("SELECT comments.*, users.username FROM comments JOIN users ON comments.user_id = users.id WHERE product_id = ? ORDER BY created_at DESC");
$stmt->execute([$id]);
$comments = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<main>
    <div class="container">
        <div class="product-detail">
            <!-- نمایش گالری تصاویر -->
            <div class="product-gallery">
                <?php if ($images): ?>
                    <div class="main-image">
                        <img id="main-img" src="<?php echo htmlspecialchars($images[0]['image']); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>">
                    </div>
                    <div class="thumbnail-container">
                        <?php foreach ($images as $img): ?>
                            <img class="thumbnail" src="<?php echo htmlspecialchars($img['image']); ?>" onclick="changeImage(this.src)">
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <img src="<?php echo htmlspecialchars($product['image']); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>">
                <?php endif; ?>
            </div>

            <!-- نمایش اطلاعات محصول -->
            <div class="product-info">
                <h2><?php echo htmlspecialchars($product['name']); ?></h2>
                <p><?php echo nl2br(htmlspecialchars($product['description'])); ?></p>
                <p class="price"><?php echo number_format($product['price']); ?> تومان</p>
                
                <form id="add-to-cart-form">
                    <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                    <input type="hidden" name="name" value="<?php echo $product['name']; ?>">
                    <input type="hidden" name="price" value="<?php echo $product['price']; ?>">
                    <input type="hidden" name="image" value="<?php echo $product['image']; ?>">
                    <input type="number" id="quantity" name="quantity" value="1" min="1">
                    <button type="submit">افزودن به سبد خرید..</button>
                </form>
                <p id="message"></p>
                
                <a href="cart.php" class="view-cart-btn">مشاهده سبد خرید</a>
            </div>
        </div>

        <!-- نظرات محصول -->
        <div class="product-comments">
            <h3>نظرات کاربران</h3>
            <?php if ($comments): ?>
                <ul>
                    <?php foreach ($comments as $comment): ?>
                        <li>
                            <strong><?php echo htmlspecialchars($comment['username']); ?>:</strong>
                            <p><?php echo nl2br(htmlspecialchars($comment['comment'])); ?></p>
                            <small><?php echo $comment['created_at']; ?></small>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php else: ?>
                <p>هنوز نظری ثبت نشده است.</p>
            <?php endif; ?>

            <?php if (isset($_SESSION['user_id'])): ?>
                <form id="comment-form">
                    <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                    <textarea name="comment" id="comment" rows="3" placeholder="نظر خود را بنویسید..."></textarea>
                    <button type="submit">ارسال نظر</button>
                </form>
                <p id="comment-message"></p>
            <?php else: ?>
                <p>برای ثبت نظر، ابتدا <a href="login.php">وارد شوید</a>.</p>
            <?php endif; ?>
            <link rel="stylesheet" href="css/product.css">
        </div>
    </div>
</main>

<script src="js/product.js"></script>
<?php include 'includes/footer.php'; ?>
