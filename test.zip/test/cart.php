<?php
session_start();
include 'includes/header.php';
include 'db.php';

$total = 0;
?>

<main>
    <div class="cart-container">
        <h2>🛒 سبد خرید</h2>
        <?php if (!empty($_SESSION['cart'])): ?>
            <table>
                <thead>
                    <tr>
                        <th>محصول</th>
                        <th>قیمت واحد</th>
                        <th>تعداد</th>
                        <th>مجموع</th>
                        <th>حذف</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($_SESSION['cart'] as $item): ?>
                        <tr>
                            <td>
                                <img src="<?php echo htmlspecialchars($item['image']); ?>" alt="<?php echo htmlspecialchars($item['name']); ?>">
                                <p><?php echo htmlspecialchars($item['name']); ?></p>
                            </td>
                            <td><?php echo number_format($item['price']); ?> تومان</td>
                            <td>
                                <button class="decrease" data-id="<?php echo $item['id']; ?>">➖</button>
                                <span class="quantity" data-id="<?php echo $item['id']; ?>"><?php echo $item['quantity']; ?></span>
                                <button class="increase" data-id="<?php echo $item['id']; ?>">➕</button>
                            </td>
                            <td><?php echo number_format($item['price'] * $item['quantity']); ?> تومان</td>
                            <td>
                                <button class="remove-btn" data-id="<?php echo $item['id']; ?>">🗑️</button>
                            </td>
                        </tr>
                        <?php $total += $item['price'] * $item['quantity']; ?>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <div class="cart-summary">
                <p><strong>مجموع کل:</strong> <?php echo number_format($total); ?> تومان</p>
            </div>

            <!-- دکمه پرداخت -->
            <form action="callback.php" method="POST">
                <input type="hidden" name="merchant" value="YOUR_MERCHANT_ID">
                <input type="hidden" name="amount" value="<?php echo $total; ?>">
                <input type="hidden" name="callback_url" value="http://yourwebsite.com/callback.php">
                <button type="submit" class="payment-btn">پرداخت از طریق درگاه زیبال</button>
            </form>
        <?php else: ?>
            <p>سبد خرید شما خالی است.</p>
        <?php endif; ?>
    </div>
</main>

<script src="js/cart.js"></script>
<?php include 'includes/footer.php'; ?>
