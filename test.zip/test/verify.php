<?php
session_start();
include 'includes/db.php';

$merchant_id = "XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX";
$track_id = $_GET['trackId'];

$data = ["merchant" => $merchant_id, "trackId" => $track_id];
$ch = curl_init("https://api.zibal.ir/v1/verify");
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
$response = json_decode(curl_exec($ch), true);
curl_close($ch);

if ($response['result'] == 100) {
    $ref_id = $response['refNumber'];
    $order_id = time();
    echo "<p>✅ پرداخت موفق بود! شماره سفارش: $order_id</p>";
    echo "<p>🔖 کد پیگیری: $ref_id</p>";

    unset($_SESSION['cart']); // پاک کردن سبد خرید
} else {
    echo "<p>❌ پرداخت ناموفق بود. لطفاً دوباره امتحان کنید.</p>";
}
?>
