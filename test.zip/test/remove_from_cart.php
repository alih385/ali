<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'لطفاً ابتدا وارد شوید']);
    exit();
}

$data = json_decode(file_get_contents('php://input'), true);
$item_id = $data['item_id'];

// حذف آیتم از سبد خرید
$stmt = $conn->prepare("DELETE FROM cart_items WHERE id = ?");
$stmt->execute([$item_id]);

echo json_encode(['status' => 'success', 'message' => 'محصول از سبد خرید حذف شد']);
?>