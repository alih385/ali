<?php
session_start();

// پاک کردن تمام اطلاعات Session
session_unset();
session_destroy();

// انتقال به صفحه ورود
header('Location: login.php');
exit();
?>