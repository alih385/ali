<footer>
    <div class="container">
        <br><br><br><br><br><br>
        <p>تمامی حقوق محفوظ است &copy; <?php echo date('Y'); ?> کالا314</p>
    </div>
</footer>

<script src="js/jquery-3.1.1.min.js"></script>
<script src="js/jquery-ui.min.js"></script>
<script src="js/scripts.js"></script>
