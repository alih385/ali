<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// محاسبه تعداد کل آیتم‌های سبد خرید
$cart_count = 0;
if (isset($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $item) {
        $cart_count += $item['quantity'];
    }
}
?>
<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>فروشگاه کالا314</title>
    <link rel="stylesheet" href="css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <header>
        <div class="container">
            <!-- لوگو و نام سایت -->
            <div class="logo">
                <a href="index.php">کالا314</a>
            </div>

            <!-- منوی محصولات -->
            <nav class="products-menu">
                <ul>
                    <li><a href="products.php?category=electronics">الکترونیک</a></li>
                    <li><a href="products.php?category=clothing">پوشاک</a></li>
                    <li><a href="products.php?category=home">خانه و آشپزخانه</a></li>
                    <li><a href="products.php?category=sports">ورزشی</a></li>
                </ul>
            </nav>

            <!-- باکس جستجو -->
            <div class="search-box">
                <input type="text" placeholder="جستجوی محصولات...">
                <button><i class="fas fa-search"></i></button>
            </div>

            <!-- بخش کاربر و سبد خرید -->
            <div class="user-actions">
                <?php if (isset($_SESSION['user_id'])): ?>
                    <span>خوش آمدید, <?php echo isset($_SESSION['username']) ? htmlspecialchars($_SESSION['username']) : 'کاربر'; ?>!</span>
                    <a href="logout.php">خروج</a>
                <?php else: ?>
                    <a href="login.php" id="login-btn">ورود به حساب</a>
                <?php endif; ?>
                <a href="cart.php" class="cart-icon">
                    <i class="fas fa-shopping-cart"></i>
                    <span id="cart-count"><?php echo $cart_count; ?></span>
                </a>
            </div>
        </div>
    </header>

    <script>
    // بروزرسانی تعداد آیتم‌های سبد خرید بدون نیاز به رفرش صفحه
    function updateCartCount() {
        fetch('cart_count.php')
        .then(response => response.json())
        .then(data => {
            document.getElementById('cart-count').textContent = data.count;
        })
        .catch(error => console.error('Error:', error));
    }

    // اجرای بروزرسانی تعداد سبد خرید در هر چند ثانیه
    setInterval(updateCartCount, 5000);
    </script>
</body>
</html>
