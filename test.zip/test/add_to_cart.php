<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'لطفاً ابتدا وارد شوید']);
    exit();
}

$user_id = $_SESSION['user_id'];
$product_id = $_POST['product_id'];
$quantity = $_POST['quantity'];

// بررسی وجود سبد خرید برای کاربر
$stmt = $conn->prepare("SELECT id FROM cart WHERE user_id = ?");
$stmt->execute([$user_id]);
$cart = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$cart) {
    // ایجاد سبد خرید جدید
    $stmt = $conn->prepare("INSERT INTO cart (user_id) VALUES (?)");
    $stmt->execute([$user_id]);
    $cart_id = $conn->lastInsertId();
} else {
    $cart_id = $cart['id'];
}

// بررسی وجود محصول در سبد خرید
$stmt = $conn->prepare("SELECT * FROM cart_items WHERE cart_id = ? AND product_id = ?");
$stmt->execute([$cart_id, $product_id]);
$item = $stmt->fetch(PDO::FETCH_ASSOC);

if ($item) {
    // اگر محصول از قبل در سبد خرید وجود دارد، تعداد آن را افزایش می‌دهیم
    $new_quantity = $item['quantity'] + $quantity;
    $stmt = $conn->prepare("UPDATE cart_items SET quantity = ? WHERE id = ?");
    $stmt->execute([$new_quantity, $item['id']]);
} else {
    // اگر محصول در سبد خرید وجود ندارد، آن را اضافه می‌کنیم
    $stmt = $conn->prepare("INSERT INTO cart_items (cart_id, product_id, quantity) VALUES (?, ?, ?)");
    $stmt->execute([$cart_id, $product_id, $quantity]);
}

echo json_encode(['status' => 'success', 'message' => 'محصول به سبد خرید اضافه شد']);
?>